// lib/models/user.dart
class User {
  String name;
  String email;
  String studentNumber;

  User({
    required this.name,
    required this.email,
    required this.studentNumber,
  });
}
