// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'pages/home.dart';
import 'pages/task.dart';
import 'providers/theme_provider.dart';
import 'pages/login.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ThemeProvider(),
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, child) {
          return MaterialApp(
            title: 'Todo List App',
            theme: themeProvider.isDarkMode
                ? ThemeData.dark().copyWith(
                    primaryColor: Colors.green,
                    hintColor: Colors.orangeAccent,
                    scaffoldBackgroundColor: Colors.black,
                    cardColor: Colors.grey[800],
                    textTheme: TextTheme(bodyText1: TextStyle(color: Colors.white)),
                  )
                : ThemeData.light().copyWith(
                    primaryColor: Colors.green,
                    hintColor: Colors.orangeAccent,
                    scaffoldBackgroundColor: Colors.white,
                    cardColor: Colors.grey[200],
                    textTheme: TextTheme(bodyText1: TextStyle(color: Colors.black)),
                  ),
            home: LoginPage(), 
            routes: {
              '/home': (context) => HomePage(),
              '/task': (context) => TaskPage(
                onTaskAdded: (title, description) {
               
                },
              ),
            },
          );
        },
      ),
    );
  }
}
