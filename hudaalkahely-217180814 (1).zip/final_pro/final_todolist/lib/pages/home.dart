// lib/pages/home.dart
import 'package:flutter/material.dart';
import 'package:todo_list_app/pages/setting.dart';
import 'task.dart'; 
import 'login.dart'; 

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Map<String, dynamic>> _tasks = [];

  void _addTask(String title, String description) {
    setState(() {
      _tasks.add({
        'title': title,
        'description': description,
        'isCompleted': false,
      });
    });
  }

  void _toggleTaskCompletion(int index) {
    setState(() {
      _tasks[index]['isCompleted'] = !_tasks[index]['isCompleted'];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('قائمة المهام'),
        backgroundColor: const Color.fromARGB(255, 168, 251, 170), 
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(8.0),
        itemCount: _tasks.length,
        itemBuilder: (context, index) {
          final task = _tasks[index];
          return _buildTaskCard(task['title'], task['description'], task['isCompleted'], index);
        },
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
           
            IconButton(
              icon: Icon(Icons.login, color: Colors.orangeAccent),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginPage(), 
                  ),
                );
              },
            ),
           
            FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TaskPage(
                      onTaskAdded: _addTask,
                    ),
                  ),
                );
              },
              backgroundColor: Colors.orangeAccent, 
              child: Icon(Icons.add, color: Colors.white),
            ),
           
            IconButton(
              icon: Icon(Icons.settings,  color: Colors.orangeAccent),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SettingsPage(), 
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTaskCard(String title, String description, bool isCompleted, int index) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            height: 100, 
            color: Colors.orangeAccent, 
            child: Center(
              child: Text(
                'Image',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: isCompleted ? Color.fromARGB(255, 39, 168, 110) : Color.fromARGB(255, 32, 81, 35),
                    decoration: isCompleted ? TextDecoration.lineThrough : TextDecoration.none,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 14,
                    color: isCompleted ? Color.fromARGB(255, 41, 141, 52) : Colors.black54,
                    decoration: isCompleted ? TextDecoration.lineThrough : TextDecoration.none,
                  ),
                ),
              ],
            ),
          ),
          Checkbox(
            value: isCompleted,
            onChanged: (bool? value) {
              _toggleTaskCompletion(index);
            },
          ),
        ],
      ),
    );
  }
}
