// lib/pages/settings_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_list_app/models/user.dart';
import '../providers/theme_provider.dart';

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = User(name: "Huda alkahely", email: 'hudalkahely@gmail.com', studentNumber: '217180814'); 
    return Scaffold(
      appBar: AppBar(
        title: Text('الإعدادات'),
         backgroundColor: const Color.fromARGB(255, 168, 251, 170), 
      ),
      body: Column(
        children: [
          ListTile(
            leading: CircleAvatar(
              child: Text(user.name[0]),
            ),
            title: Text(user.name),
            subtitle: Text('${user.email}\nStudent Number: ${user.studentNumber}'),
          ),
          ListTile(
            title: Text('اللغة'),
            trailing: DropdownButton<String>(
              items: [
                DropdownMenuItem(value: 'English', child: Text('الانجليزية')),
                DropdownMenuItem(value: 'Arabic', child: Text('العربية')),
              ],
              onChanged: (value) {},
            ),
          ),
          ListTile(
            title: Text('التنسيق المظلم'),
            trailing: Switch(
              value: Provider.of<ThemeProvider>(context).isDarkMode,
              onChanged: (value) {
                Provider.of<ThemeProvider>(context, listen: false).toggleTheme();
              },
            ),
          ),
          ListTile(
            title: Text('تسجيل الخروج'),
            onTap: () {
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
    );
  }
}
