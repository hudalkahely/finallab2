// lib/pages/task.dart
import 'package:flutter/material.dart';

class TaskPage extends StatefulWidget {
  final Function(String, String) onTaskAdded;

  TaskPage({required this.onTaskAdded});

  @override
  _TaskPageState createState() => _TaskPageState();
}

class _TaskPageState extends State<TaskPage> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();

  Future<void> _addTask() async {
    final title = _titleController.text;
    final description = _descriptionController.text;

    if (title.isNotEmpty && description.isNotEmpty) {
      // عرض نافذة التحميل
      showDialog(
        context: context,
        barrierDismissible: false, // يمنع إغلاق النافذة بالضغط خارجها
        builder: (context) => Center(
          child: CircularProgressIndicator(),
        ),
      );

      // محاكاة تأخير لإظهار نافذة التحميل
      await Future.delayed(Duration(seconds: 2));

      // إغلاق نافذة التحميل
      Navigator.pop(context);

      // إضافة المهمة
      widget.onTaskAdded(title, description);

      // العودة إلى صفحة الرئيسية
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('أضف مهمة جديدة'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'عنوان المهمة',
                hintText: 'اكتب عنوان المهمة',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(
                labelText: 'وصف المهمة',
                hintText: 'ادخل وصف المهمة',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _addTask,
              style: ElevatedButton.styleFrom(
                primary: Color.fromARGB(255, 167, 242, 169), // لون الزر
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero, // حواف الزر مربعة
                ),
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
              child: Text(
                'إضافة',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
