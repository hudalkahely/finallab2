// lib/pages/login.dart
import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'مشروع العملي',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 32),
            TextField(
              decoration: InputDecoration(
                labelText: 'البريد الإلكتروني',
                hintText: 'ادخل بريدك الإلكتروني',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                labelText: 'رقم القيد',
                hintText: 'ادخل رقم قيدك',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 24),
            Container(
  width: double.infinity, 
  child: ElevatedButton(
    onPressed: () {
      Navigator.pushReplacementNamed(context, '/home');
    },
    style: ElevatedButton.styleFrom(
      primary: Colors.orangeAccent, 
      padding: EdgeInsets.symmetric(vertical: 16), 
    ),
    child: Text(
      'تسجيل الدخول',
      style: TextStyle(
        fontSize: 18,
        color: Colors.white,
      ),
    ),
  
                
              ),
            ),
          ],
        ),
      ),
    );
  }
}
